$(document).ready(function() {
	$('.timepicker').timepicker();
});
